﻿using BooksApi.Entities.Entities;
using Microsoft.AspNetCore.Mvc;
using BooksApi.Services;

namespace BooksApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly BookService bookService;

        public BookController(BookService bookService)
        {
            this.bookService = bookService;
        }

        [HttpPost("Add")]
        public ActionResult AddBook(BookDetails book)
        {
            bookService.AddBook(book);
            return Ok("Book created!");
        }

        [HttpGet("GetAll")]
        public ActionResult GetAll()
        {
            return Ok(bookService.GetAll());
        }

        [HttpGet("GetById")]
        public ActionResult GetById(int id)
        {
            var res = bookService.GetBookById(id);
            if (res != null)
                return Ok(res);

            return NotFound("Book not found!");
        }
    }
}




