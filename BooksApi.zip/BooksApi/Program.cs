using BooksApi.Entities.Context;
using BooksApi.Services;
using Microsoft.EntityFrameworkCore;

namespace BookApi
{
    public class Program
    {
         static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllers();

            // Swagger / OpenAPI configuration
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // DbContext with PostgreSQL
            builder.Services.AddDbContext<BookDbContext>(options =>
                options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

            /*
             * AddSingleton - Single Instance For All Requests
             * AddScoped - Single Instance For One Request
             * AddTransient - New Instance For Every Call
             */
            builder.Services.AddSingleton<BookService>();

            var app = builder.Build();

            // Configure HTTP request pipeline
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();
            app.MapControllers();
            app.Run();
        }
    }
}
